list.Set( "PlayerOptionsModel", "Erkus", "models/LeymiRBA/Erkus/Erkus.mdl" )
player_manager.AddValidModel( "Erkus", "models/LeymiRBA/Erkus/Erkus.mdl" )
player_manager.AddValidHands( "Erkus", "models/LeymiRBA/Erkus/Erkus_Arms.mdl", 0, "00000000" )




